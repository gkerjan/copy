# Solution Description

We started with the task 2.1. For the 1D noise, we applied the given formulas. We get the two grid points, we calculate each gradient and then we evaluate their linear interpolation.
We then implemented the fraction Brownian motion in 1D by simply implementing the given formula with a for loop.
As for the perlin_noise in 2D, we implemented the formulas by following the given figure. Same for the FBM and the Turbulence, with their respective formulas.
For the textures in Task 5.1, we also implemented the given formulas.
For the terrain, we triangulate the grid cells. And, for each of them, we applied the material texture according to the height of the cell and the water level. We then copied our Blinn-Phong implementation.

# Contributions

Gersende Kerjan (358305): 1/3

Claire Chaffard (358435): 1/3

Ardi Cerkini (357121): 1/3